let list = document.getElementById("myList");
const task = document.getElementById("task");

let data = [];

function addTask() {
    taskValue = task.value;
    if (taskValue != "") {
        data.push(taskValue);
        list.innerHTML = "";
        data.forEach((item) => {
            let li = document.createElement("li");
            li.innerText = item;
            list.appendChild(li);
        });
        task.value = '';
    }
}

document.getElementById("myList").addEventListener("click", function (e) {
    var tgt = e.target;
    data = data.filter(e => e !== tgt.innerHTML);
    if (tgt.tagName.toUpperCase() == "LI") {
        tgt.parentNode.removeChild(tgt);
    }
});